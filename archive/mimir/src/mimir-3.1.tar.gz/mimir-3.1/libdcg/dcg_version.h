/*
   File: dcg_version.h
   Generated on: Sat Dec 22 17:20:15 CET 2012
*/
#ifndef IncDcgVersion
#define IncDcgVersion
#define DCG_VERSION "3.1"
#endif /* IncDcgVersion */
