/*
   File: imc_opt.h
   Optimizes intermediate code

   CVS ID: "$Id: imc_opt.h,v 1.3 2005/02/25 20:08:35 marcs Exp $"
*/
#ifndef IncImcOpt
#define IncImcOpt

/* exported code */
void intermediate_code_optimization ();

#endif /* IncImcOpt */
