/*
   File: backend.h
   Finishes the compilation by assembling and linking the code

   CVS ID: "$Id: backend.h,v 1.3 2005/02/25 20:08:35 marcs Exp $"
*/
#ifndef IncBackend
#define IncBackend

/* exported code */
void assemble_and_link ();

#endif /* IncBackend */
