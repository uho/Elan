/*
   File: warshall.h
   Implements Warshalls algorithm
  
   CVS ID: "$Id: warshall.h,v 1.2 2005/02/25 20:08:37 marcs Exp $"
*/
#ifndef IncWarshall
#define IncWarshall

/* exported code */
char *warshall (int n, char *rel);

#endif /* IncWarshall */
